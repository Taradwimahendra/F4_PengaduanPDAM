# Buat Excel (.xlsx) tanpa module tambahan - pakai COM Excel
# Fallback: kalau Excel tidak terinstall, pakai CSV lalu convert

$outputPath = "c:\Users\TaraDwiMahendra\Documents\PDAM\PengaduanPDAM\DataImportPengaduan.xlsx"

try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    
    $workbook = $excel.Workbooks.Add()
    $sheet = $workbook.Worksheets.Item(1)
    $sheet.Name = "Pengaduan"
    
    # Header
    $headers = @("UserID", "KategoriID", "Judul_Laporan", "Deskripsi_Laporan", "Tanggal_Pengaduan", "StatusPengaduan")
    for ($i = 0; $i -lt $headers.Count; $i++) {
        $sheet.Cells.Item(1, $i + 1) = $headers[$i]
        $sheet.Cells.Item(1, $i + 1).Font.Bold = $true
        $sheet.Cells.Item(1, $i + 1).Interior.Color = 0xD9E1F2  # Light blue
    }
    
    # Data rows
    $data = @(
        @(1, 1, "Air Mati Total", "Air di perumahan Griya Indah mati sejak kemarin sore, semua warga terdampak.", "2026-06-20", "menunggu"),
        @(1, 2, "Tagihan Tidak Sesuai", "Tagihan bulan Juni membengkak padahal pemakaian normal, mohon dicek meteran.", "2026-06-18", "menunggu"),
        @(1, 1, "Pipa Bocor di Jalan Utama", "Ada kebocoran pipa besar di Jl. Magelang Km 5, air menyembur ke jalan raya.", "2026-06-15", "diproses"),
        @(1, 1, "Air Keruh Berbau", "Air PDAM berwarna kuning dan berbau sejak 3 hari lalu, tidak layak pakai.", "2026-06-10", "menunggu"),
        @(1, 2, "Meteran Rusak", "Meteran air di rumah saya tidak berputar tapi tagihan tetap tinggi setiap bulan.", "2026-06-08", "menunggu")
    )
    
    for ($row = 0; $row -lt $data.Count; $row++) {
        for ($col = 0; $col -lt $data[$row].Count; $col++) {
            $sheet.Cells.Item($row + 2, $col + 1) = $data[$row][$col]
        }
    }
    
    # Auto-fit columns
    $sheet.UsedRange.EntireColumn.AutoFit() | Out-Null
    
    # Save
    $workbook.SaveAs($outputPath, 51) # 51 = xlOpenXMLWorkbook (.xlsx)
    $workbook.Close()
    $excel.Quit()
    
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null
    
    Write-Host "File Excel berhasil dibuat di: $outputPath"
}
catch {
    Write-Host "Error: $_"
    Write-Host "Mencoba fallback..."
    
    # Cleanup COM jika error
    try { $excel.Quit() } catch {}
}
